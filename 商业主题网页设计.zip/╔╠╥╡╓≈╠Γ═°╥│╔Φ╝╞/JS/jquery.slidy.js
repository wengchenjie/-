(function($) {
    $.fn.Slide = function(options) {
        var opts = $.extend({},
        $.fn.Slide.deflunt, options);
        var index = 1;
        var targetLi = $("." + opts.claNav + " li", $(this));
        var clickNext = $("." + opts.claNav + " .next", $(this));
        var clickPrev = $("." + opts.claNav + " .prev", $(this));
        var ContentBox = $("." + opts.claCon, $(this));
        var ContentBoxNum = ContentBox.children().size();
        var slideH = ContentBox.children().first().height();
        var slideW = ContentBox.children().first().width();
        var autoPlay;
        var slideWH;
        if (opts.effect == "scroolY" || opts.effect == "scroolTxt") {
            slideWH = slideH;
        } else if (opts.effect == "scroolX" || opts.effect == "scroolLoop") {
            ContentBox.css("width", ContentBoxNum * slideW);
            slideWH = slideW;
        } else if (opts.effect == "fade") {
            ContentBox.children().first().css("z-index", "1");
        }
        return this.each(function() {
            var $this = $(this);
            var doPlay = function() {
                $.fn.Slide.effect[opts.effect](ContentBox, targetLi, index, slideWH, opts);
                index++;
                if (index * opts.steps >= ContentBoxNum) {
                    index = 0;
                }
            };
            clickNext.click(function(event) {
                $.fn.Slide.effectLoop.scroolLeft(ContentBox, targetLi, index, slideWH, opts,
                function() {
                    for (var i = 0; i < opts.steps; i++) {
                        ContentBox.find("li:first", $this).appendTo(ContentBox);
                    }
                    ContentBox.css({
                        "left": "0"
                    });
                });
                event.preventDefault();
            });
            clickPrev.click(function(event) {
                for (var i = 0; i < opts.steps; i++) {
                    ContentBox.find("li:last").prependTo(ContentBox);
                }
                ContentBox.css({
                    "left": -index * opts.steps * slideW
                });
                $.fn.Slide.effectLoop.scroolRight(ContentBox, targetLi, index, slideWH, opts);
                event.preventDefault();
            });
            if (opts.autoPlay) {
                autoPlay = setInterval(doPlay, opts.timer);
                ContentBox.hover(function() {
                    if (autoPlay) {
                        clearInterval(autoPlay);
                    }
                },
                function() {
                    if (autoPlay) {
                        clearInterval(autoPlay);
                    }
                    autoPlay = setInterval(doPlay, opts.timer);
                    if ($("#Html5Video").attr('_isplaying')) {
                        clearInterval(autoPlay);
                    }
                });
            }
           
            targetLi.click(function() {
                index = targetLi.index(this);
                window.setTimeout(function() {
                    $.fn.Slide.effect[opts.effect](ContentBox, targetLi, index, slideWH, opts);
                },
                10);
            });
        });
    };
    $.fn.Slide.deflunt = {
        effect: "scroolY",
        autoPlay: true,
        speed: "normal",
        timer: 1000,
        defIndex: 0,
        claNav: "bannermenu",
        claCon: "caseul",
        steps: 1
    };
    $.fn.Slide.effectLoop = {
        scroolLeft: function(contentObj, navObj, i, slideW, opts, callback) {
            contentObj.animate({
                "left": -i * opts.steps * slideW
            },
            opts.speed, callback);
            if (navObj) {
                navObj.eq(i).addClass("on").siblings().removeClass("on");
            }
        },
        scroolRight: function(contentObj, navObj, i, slideW, opts, callback) {
            contentObj.stop().animate({
                "left": 0
            },
            opts.speed, callback);
        }
    }
    $.fn.Slide.effect = {
        fade: function(contentObj, navObj, i, slideW, opts) {
            contentObj.children().eq(i).stop().animate({
                opacity: 1
            },
            opts.speed).css({
                "z-index": "1"
            }).siblings().animate({
                opacity: 0
            },
            opts.speed).css({
                "z-index": "0"
            });
            navObj.eq(i).addClass("on").siblings().removeClass("on");
        },
        scroolTxt: function(contentObj, undefined, i, slideH, opts) {
            contentObj.animate({
                "margin-top": -opts.steps * slideH
            },
            opts.speed,
            function() {
                for (var j = 0; j < opts.steps; j++) {
                    contentObj.find("li:first").appendTo(contentObj);
                }
                contentObj.css({
                    "margin-top": "0"
                });
            });
        },
        scroolX: function(contentObj, navObj, i, slideW, opts, callback) {
            contentObj.stop().animate({
                "left": -i * opts.steps * slideW
            },
            opts.speed, callback);
            if (navObj) {
                navObj.eq(i).addClass("on").siblings().removeClass("on");
            }
        },
        scroolY: function(contentObj, navObj, i, slideH, opts) {
            contentObj.stop().animate({
                "top": -i * opts.steps * slideH
            },
            opts.speed);
            if (navObj) {
                navObj.eq(i).addClass("on").siblings().removeClass("on");
            }
        }
    };
})(jQuery);
$(function(){
	$(window).scroll(function(){  //只要窗口滚动,就触发下面代码 
		var scrollt = document.documentElement.scrollTop + document.body.scrollTop; //获取滚动后的高度 
		if( scrollt >200 ){  //判断滚动后高度超过200px,就显示  
			$("#gotop").fadeIn(400); //淡出     
		}else{      
			$("#gotop").stop().fadeOut(400); //如果返回或者没有超过,就淡入.必须加上stop()停止之前动画,否则会出现闪动   
		}
	});
	$("#gotop").click(function(){ //当点击标签的时候,使用animate在200毫秒的时间内,滚到顶部
			$("html,body").animate({scrollTop:"0px"},200);
	});
});
function i_slide(obj,opt){
  var option={
		speed:"5000",//间隔运动时间
		a_speed:"500",//运动时间
		conuntW:"1180",//整体内容宽度
		countH:"530",//整体内容高度
		w1:"800",//大图宽度
		h1:"530",//大图高度
		w2:"190",//小图宽度
		h2:"500"//小图高度  
	  }
  
  var ul=obj.find("ul.slide_img");
  var btn=obj.find(".i_btn");
  var con=ul.find(".on");
  var li=ul.children("li");
  var lion=ul.children("li.on");
  var length=li.length;
  var half=parseInt(length/2);
  var number;
  var T;	
  var start;
	//参数初始化,看是否有新的参数传入，传入则更新初始化设置  
	var opts = $.extend(option, opt || {}); 
	var speed=opts.speed;
	var a_speed=opts.a_speed;
	var conuntW=opts.conuntW;//整体内容宽度
	var countH=opts.countH;//整体内容高度
	var w1=opts.w1;//大图宽度
	var h1=opts.h1;//大图高度
	//大图left
	var left1=(opts.conuntW-opts.w1)/2;
	//大图top
	var top1=(opts.countH-opts.h1)/2;
	var left2=opts.conuntW-opts.w2;//小图left
	//小图top
	var top2=(opts.countH-opts.h2)/2; 
	var w2=opts.w2;//小图宽度
	var h2=opts.h2;//小图高度

  if(length%2==0){
	  half=half-1;
	  }
	
//默认轮播
   clearInterval(T)
  number=parseInt(now_show(li))
  pos_dex(number)
  T= setInterval(function(){
	 ss();
	 pos_dex(number)
	 },speed)
   //重新定位
   
   function pos_dex(N){ 
		var next;
		var z=li.length;
	//	alert(z);
		li.eq(N).attr("class","on"); 
		li.eq(N).find(".icon").show();
	    li.eq(N).siblings("li").find(".bg").hide();
	    li.eq(N).siblings("li").find(".info").hide(); 
		for(i=1;i<=half;i++){
			 //right
			  next=N+i;
			  z=z-i
			  if(next==length){
				  next=0;
				  }
			 li.eq(next).css("z-index",z);
			 li.eq(next).attr("class","right");
			 li.eq(next).animate({"left":left2,"width":w2,"height":h2,"top":top2},a_speed);
			 // li.eq(next).css("z-index",z);
			  //left 
			  var pre=N-i;
			  if(pre==-1){
				  pre=length-1;
			    }
			 li.eq(pre).attr("class","left"); 
			 li.eq(pre).css("z-index",z);
			 // li.eq(pre).css("z-index",z);
			  li.eq(pre).animate({"left":"0px","width":w2,"height":h2,"top":top2},a_speed);
			} 
			//mid
	       if(length%2==0){
			  li.eq(next+1).attr("class","mid");
			 li.eq(next+1).css("z-index",z-2);
			  li.eq(next+1).animate({"left":left2,"width":w2,"height":h2,"top":top2},a_speed);
			  }
		   //li.eq(N).css("z-index",length);
		   li.eq(N).css("z-index",parseInt(length)+3);
		   li.eq(N).animate({"left":left1,"width":w1,"height":h1,"top":top1},a_speed);
	   }
   //当前显示的是第几个图片
  function now_show(chi){
		var now=0;
		for(i=0;i<chi.length;i++){
			var li=chi[i];
			if($(li).hasClass("on")){
				now=i;  
				}  
			}
		  return now;
	}
  //点击前后按钮切换
   var arr=[];
   var flg;
   btn.unbind('click').click(function(){
	   clearInterval(T);
	   number=parseInt(now_show(li));
		var tip=$(this).attr("tip");
		 if(tip==0){
			 //向前
			if(number==0){
				number=length-1;
				}else{
				number=number-1;	
					}
		 }else{
			//向后
			if(number==length-1){
				number=0;
				}else{
				number=number+1;	
					} 
			 }
		 if(!lion.is(":animated")){
			     pos_dex(number);
				 T= setInterval(function(){
				 ss();
				 pos_dex(number)
				 },speed)
			 }	 
		 
		 
	   })
  //鼠标点击
   ul.on("click","li.on .icon",function(){
	    clearInterval(T);
		$(this).hide()
	    $(this).siblings(".info").show();
		$(this).siblings(".bg").show();
	   })
   li.on("click",".info i",function(){  
         $(this).parent(".info").siblings(".icon").show(); 
	     $(this).parent(".info").hide();
		 $(this).parent(".info").siblings(".bg").hide();
		 number=parseInt(now_show(li))
	    setTimeout(function(){
		     T= setInterval(function(){
				 ss();
				 pos_dex(number)
				 },speed)
		   },300);
		   return false;
	  })
   function ss(){
	     number=number+1;
	     if(number==length){
		 number=0;  
		 }
	   }
	
	}